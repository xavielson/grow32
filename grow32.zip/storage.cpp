#include "storage.h"
#include <FS.h>
#include <SPIFFS.h>
#include <ArduinoJson.h>

// Ajuste o tamanho do JSON se necessário para mais campos
#define STORAGE_JSON_SIZE 4096

bool storage_init() {
    return SPIFFS.begin(true);
}

bool storage_save(RelayConfig relays[], size_t num_relays) {
    StaticJsonDocument<STORAGE_JSON_SIZE> doc;
    JsonArray arr = doc.createNestedArray("relays");
    for (size_t i = 0; i < num_relays; i++) {
        JsonObject o = arr.createNestedObject();
        o["name"] = relays[i].name;
        o["type"] = relays[i].type;
        o["wavemaker_mode"] = relays[i].wavemaker_mode;
    }
    File f = SPIFFS.open("/relays.json", "w");
    if (!f) return false;
    serializeJson(doc, f);
    f.close();
    return true;
}

bool storage_load(RelayConfig relays[], size_t num_relays) {
    File f = SPIFFS.open("/relays.json", "r");
    if (!f) return false;
    StaticJsonDocument<STORAGE_JSON_SIZE> doc;
    DeserializationError err = deserializeJson(doc, f);
    if (err) {
        f.close();
        return false;
    }
    JsonArray arr = doc["relays"];
    for (size_t i = 0; i < arr.size() && i < num_relays; i++) {
        JsonObject o = arr[i];
        relays[i].name = String((const char*)o["name"]);
        relays[i].type = String((const char*)o["type"]);
        relays[i].wavemaker_mode = o["wavemaker_mode"] | -1; // fallback para -1 caso não exista
    }
    f.close();
    return true;
}
