#pragma once
#include <Arduino.h>
#include "relay.h" 

bool storage_init();
bool storage_save(RelayConfig relays[], size_t num_relays);
bool storage_load(RelayConfig relays[], size_t num_relays);